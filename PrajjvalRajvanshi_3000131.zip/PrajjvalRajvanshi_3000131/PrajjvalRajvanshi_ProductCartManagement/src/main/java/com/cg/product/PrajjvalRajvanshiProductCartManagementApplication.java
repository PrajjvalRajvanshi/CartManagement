package com.cg.product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrajjvalRajvanshiProductCartManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrajjvalRajvanshiProductCartManagementApplication.class, args);
	}

}
