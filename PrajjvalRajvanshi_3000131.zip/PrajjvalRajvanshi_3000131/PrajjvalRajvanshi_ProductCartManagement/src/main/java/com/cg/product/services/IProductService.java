package com.cg.product.services;
import java.util.List;
import com.cg.product.bean.Product;
import com.cg.product.exceptions.ProductDetailsNotFoundException;

public interface IProductService {
	public Product createProduct(Product product);
	public boolean updateProduct(String id,Product product) throws ProductDetailsNotFoundException;
	public boolean deleteProduct(String id)throws ProductDetailsNotFoundException;
	public List<Product> viewProducts();
	public Product findProduct(String id)throws ProductDetailsNotFoundException;
}
