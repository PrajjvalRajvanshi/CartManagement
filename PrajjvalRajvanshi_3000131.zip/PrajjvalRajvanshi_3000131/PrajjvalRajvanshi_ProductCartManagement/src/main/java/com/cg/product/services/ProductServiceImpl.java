package com.cg.product.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.product.bean.Product;
import com.cg.product.daoservices.IProductRepo;
import com.cg.product.exceptions.ProductDetailsNotFoundException;

@Component("productServices")
public class ProductServiceImpl implements IProductService {
	int COUNT=0;
	@Autowired
	IProductRepo productDAO;
	//To create a new Product and taking input from form 
	@Override
	public Product createProduct(Product product) {
		product = productDAO.save(product);
		return product;
	}
	
	//To update existing Product Details
	@Override
	public boolean updateProduct(String id, Product product) throws ProductDetailsNotFoundException{
		createProduct(product);
		product.setId(id);
		productDAO.save(product);
		return true;
	}
	
	//To delete Product Details using ProductID
	@Override
	public boolean deleteProduct(String id)throws ProductDetailsNotFoundException {
		productDAO.delete(findProduct(id));
		return true;
	}
	
	//To view All products in database
	@Override
	public List<Product> viewProducts() {
		if(COUNT<1){
			productDAO.save(new Product("i01", "Iphone", "6s", 45000));
			productDAO.save(new Product("s01", "Samsung", "GalaxyS9", 55000));
			productDAO.save(new Product("m01", "Motorola", "MottoM7", 29000));
			COUNT++;
		}
		return productDAO.findAll();
	}

	//To find a product details using product ID
	@Override
	public Product findProduct(String id) throws ProductDetailsNotFoundException {
		if(COUNT<1){
			productDAO.save(new Product("i01", "Iphone", "6s", 45000));
			productDAO.save(new Product("s01", "Samsung", "GalaxyS9", 55000));
			productDAO.save(new Product("m01", "Motorola", "MottoM7", 29000));
			COUNT++;
		}
		Product product = productDAO.findById(id).orElseThrow(()->new ProductDetailsNotFoundException("Product Details not Found for ID "+id));
		return product;
	}

}
